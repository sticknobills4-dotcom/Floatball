package com.santhosh.floatball

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private var ball: TextView? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("fb", "FloatBall", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "fb")
            .setContentTitle("FloatBall running")
            .setContentText("Ball tap panna screenshot edukkum")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        addBall()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addBall() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = dp(56)
        val v = TextView(this).apply {
            text = "📷"; textSize = 22f; gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC1565C0"))
            }
            alpha = 0.9f
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(300) }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx; val dy = e.rawY - ty
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) { lp.x = (sx + dx).toInt(); lp.y = (sy + dy).toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) shoot()
            }
            true
        }
        wm.addView(v, lp)
        ball = v
    }

    private fun shoot() {
        val svc = ShotService.instance
        if (svc == null) {
            Toast.makeText(this, "Accessibility service ON pannu (app la button)", Toast.LENGTH_LONG).show()
            return
        }
        ball?.visibility = View.INVISIBLE   // ball screenshot la varakoodathu
        Handler(Looper.getMainLooper()).postDelayed({
            svc.capture { ball?.visibility = View.VISIBLE }
        }, 250)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        ball?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
