package com.santhosh.floatball

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { a() } })

        root.addView(TextView(this).apply {
            text = "FloatBall\n\nStep 1 → 2 → 3 follow pannu"; textSize = 18f
        })
        btn("1. Overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Accessibility ON (FloatBall)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3. Start floating ball") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "First overlay permission kudu", Toast.LENGTH_SHORT).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33)
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                startForegroundService(Intent(this, FloatingService::class.java))
            }
        }
        btn("Stop ball") { stopService(Intent(this, FloatingService::class.java)) }
        btn("Battery optimisation off (Xiaomi/Oppo/Vivo)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        setContentView(root)
    }
}
